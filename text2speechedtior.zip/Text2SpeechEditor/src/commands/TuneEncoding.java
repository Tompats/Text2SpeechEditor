package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import encodingstrategies.StrategiesFactory;
import model.Document;

public class TuneEncoding implements ActionListener,Cloneable {

	private StrategiesFactory factory = new StrategiesFactory();
	private String type;
	private Document currentDocument;
	private ReplayManager replayManager;
	
	public TuneEncoding(Document currentDocument,String type, ReplayManager replayManager) {
		this.type = type;
		this.currentDocument = currentDocument;
		this.replayManager = replayManager;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		currentDocument.tuneEncodingStrategy(factory.createStrategy(type));
		try {
			replayManager.setArray((ActionListener) clone());
		} catch (CloneNotSupportedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
}
