package commands;

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.io.File;
import java.awt.event.ActionListener;

public class HelpViewer implements ActionListener, Cloneable {

	private File pdfFile;
	private ReplayManager replayManager;


	public HelpViewer(ReplayManager replaymanager) {
		this.replayManager = replaymanager;
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		executeHelpFile();
	}
	

	
	
	public void executeHelpFile() {
		try {
			pdfFile = new File("Text2SpeechEditorUserManual.pdf");
			if (pdfFile.exists()) {
	
				if (Desktop.isDesktopSupported()) {
					replayManager.setArray((ActionListener) clone());
					Desktop.getDesktop().open(pdfFile);
				} 
				else {
					System.out.println("Awt Desktop is not supported!");
				}
	
			} 
			else {
				 String current = null;
					try {
						current = new java.io.File( "." ).getCanonicalPath();
						pdfFile = new File(current);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
			}
			//System.out.println("Done");
	
		} 
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 

}
