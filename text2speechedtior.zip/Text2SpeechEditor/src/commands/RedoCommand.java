package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.undo.UndoManager;



public class RedoCommand implements ActionListener{
	private UndoManager manager;
	
	
	public RedoCommand(UndoManager manager) {
		this.manager = manager;
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(manager.canRedo()) {
			manager.redo();
		}

	}

}
