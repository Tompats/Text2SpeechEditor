package commands;

import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;

import model.Document;

public class ReplayManager {
		private ArrayList<ActionListener> replayCommandsArray = new ArrayList<ActionListener>();
		private Document currentDocument;
		private String title;
		private String author;
		private JFrame messageFrame;
		
		public ReplayManager(Document currentDocument) {
			this.currentDocument = currentDocument;
		}
		
		public void setArray(ActionListener actionListener) {
			replayCommandsArray.add(actionListener);
			//System.out.println(replayCommandsArray);
		}
		public ArrayList<ActionListener> getArray() {
			return replayCommandsArray;
		}
		public Document getDocument() {
			return currentDocument;
		}

		public void setTitle(String title) {
			// TODO Auto-generated method stub
			this.title = title;
		}

		public void setFrame(JFrame messageFrame) {
			this.messageFrame = messageFrame;
			
		}

		public void setAuthor(String author) {
			this.author = author;
			
		}
		public String getTitle() {
			return title;
		}

		public JFrame getFrame() {
			return messageFrame;
			
		}

		public String getAuthor() {
			return author;
			
		}

		public void clear(int counter) {
			//ArrayList<ActionListener> newCommandsArray = new ArrayList<ActionListener>();
			for(int i=0;i<counter;i++) {
				//if(replayCommandsArray.size()-1 >= counter) {
					replayCommandsArray.remove(replayCommandsArray.size()-1);
				//}
			}
			//replayCommandsArray = newCommandsArray;

		}
}
