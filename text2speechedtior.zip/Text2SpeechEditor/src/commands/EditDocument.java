package commands;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import model.Document;
import model.Line;

public class EditDocument implements ActionListener,Cloneable {

	private ArrayList<Line> lines = new ArrayList<Line>();
	private JTextArea textArea;
	private Document currentDocument;
	
	public EditDocument(JTextArea textArea,Document currentDocument) {
		this.textArea=textArea;
		this.currentDocument=currentDocument;
	}
	
	public void getString() {
		String getTexts = new String();
		getTexts = textArea.getText();
		String[] linesArray = getTexts.split("\n");
		String[] wordsArray;
		for(int i=0;i<linesArray.length;i++) {
			wordsArray=linesArray[i].split(" ");
			Line line = new Line();
			line.setWords(wordsArray);
			lines.add(line);
			//System.out.println(line);
		}
		currentDocument.setLines(lines);
		//System.out.println(lines);
	}

	public void actionPerformed(ActionEvent e) {
		lines = new ArrayList<Line>();
		currentDocument.deleteLinesArrayList();
		getString();
	} 
}
