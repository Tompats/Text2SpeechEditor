package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Document;

public class EncodedDocumentToSpeech implements ActionListener,Cloneable {

	private Document currentDocument;
	private ReplayManager replayManager;
	
	public EncodedDocumentToSpeech(Document currentDocument, ReplayManager replayManager) {
		this.currentDocument = currentDocument;
		this.replayManager = replayManager;
	}

	public void actionPerformed(ActionEvent e) {
		currentDocument.playEncodedContents();
		try {
			replayManager.setArray((ActionListener) clone());
		} catch (CloneNotSupportedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
}
