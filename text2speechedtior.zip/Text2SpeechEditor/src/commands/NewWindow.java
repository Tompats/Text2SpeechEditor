package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.Text2SpeechEditorView;

public class NewWindow implements ActionListener, Cloneable {

    private ReplayManager replayManager;

	public NewWindow(ReplayManager replayManager) {
		this.replayManager = replayManager;
	}

	public void actionPerformed(ActionEvent e) {
			try {
				replayManager.setArray((ActionListener) clone());
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        Text2SpeechEditorView newMainItem = new Text2SpeechEditorView();
        newMainItem.initialize();
    }
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 

}
		
	