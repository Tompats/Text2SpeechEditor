package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.SwingWorker;

public class ReplayCommand implements ActionListener  {
	
	private ActionListenerTask sw1;
	private ArrayList<ActionListener> replayCommandsArray;
	private ReplayManager replayManager;

	public ReplayCommand(ReplayManager replayManager) {
		this.replayManager = replayManager;
		replayCommandsArray = this.replayManager.getArray();
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		sw1 = new ActionListenerTask(replayManager,replayCommandsArray);
		SwingWorker<Integer,ActionListener> sw2 = sw1.create();
		sw2.execute();
	}

}




