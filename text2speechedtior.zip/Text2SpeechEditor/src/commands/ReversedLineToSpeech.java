package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Document;

public class ReversedLineToSpeech implements ActionListener,Cloneable {

	private Document currentDocument;
	private int line;
	private ReplayManager replayManager;
	
	
	public ReversedLineToSpeech(Document currentDocument,int line, ReplayManager replayManager) {
		this.currentDocument = currentDocument;
		this.line = line;
		this.replayManager = replayManager;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		currentDocument.playReverseLine(line);
		try {
			replayManager.setArray((ActionListener) clone());
		} catch (CloneNotSupportedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 

}
