package commands;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import model.Document;

public class NewDocument implements ActionListener,Cloneable {
	private Document currentDocument;
	private String title="";
	private String author="";
	private JFrame messageFrame;
	private JTextArea textarea;
	private ReplayManager replayManager;
	
	public NewDocument(Document currentDocument,String title,String author, JFrame messageFrame,JTextArea textarea, ReplayManager replayManager) {
		this.currentDocument = currentDocument;
		this.title = title;
		this.author = author;
		this.messageFrame = messageFrame;
		this.textarea= textarea;
		this.replayManager = replayManager;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		try {
		currentDocument.deleteLinesArrayList();
		currentDocument.setAuthor(author);
		currentDocument.setTitle(title);
		currentDocument.setNewDateCreated();
		//currentDocument.setNewDateSaved();
		textarea.setText(null);
		messageFrame.dispose();
		replayManager.setArray((ActionListener) clone());
		System.out.println(currentDocument);
		}
		catch(NullPointerException | CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
	public JFrame getFrame() {
		return messageFrame;
	}
	public void setFrame(JFrame frame) {
		 messageFrame = frame;
	}
	public void setAuthor(String author) {
		 this.author = author;
	}
	public void setTitle(String title) {
		 this.title = title;
	}
	public String getTitle() {
		return title;
	}
}
	