package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;

public class DeleteCommand implements ActionListener {
	
	private JTextArea textArea;


	public DeleteCommand(JTextArea textArea) {
		this.textArea = textArea;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (textArea.getSelectedText() != null) { 
			textArea.replaceSelection("");
	    }
	}

}
