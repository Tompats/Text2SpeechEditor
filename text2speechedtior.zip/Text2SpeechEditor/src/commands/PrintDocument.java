package commands;


import java.awt.event.ActionEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


import java.awt.event.ActionListener;

public class PrintDocument implements ActionListener,Cloneable{
    private JTextArea textArea;
    private ReplayManager replayManager;
 
    public PrintDocument(JTextArea textArea,ReplayManager replayManager) {
    	this.textArea = textArea;
    	this.replayManager = replayManager;
    }
    
    
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if(textArea.getText().isEmpty() != true) {
				textArea.print();
				replayManager.setArray((ActionListener) clone());
			}
			else {
				JFrame frame = new JFrame("JOptionPane showMessageDialog component example");
		    	JOptionPane.showMessageDialog(frame,"You cannot print empty document!");
			}
		} catch (java.awt.print.PrinterException | CloneNotSupportedException ex) {
		    //ex.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
}

