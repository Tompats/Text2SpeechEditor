package commands;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;

public class ZoomOut implements ActionListener,Cloneable {

	private JTextArea textArea;
	private ReplayManager replayManager;
	
	public ZoomOut(JTextArea textArea,ReplayManager replayManager) {
		this.textArea = textArea;
		this.replayManager = replayManager;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Font font = textArea.getFont();
		float size = font.getSize() - 4.0f;
		if(size>=12) {
			textArea.setFont( font.deriveFont(size) );
			try {
				replayManager.setArray((ActionListener) clone());
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
	
	
}

