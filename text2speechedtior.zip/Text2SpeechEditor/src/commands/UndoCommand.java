package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;
import javax.swing.undo.UndoManager;

public class UndoCommand implements ActionListener{
	private UndoManager manager = new UndoManager();
	private JTextArea textArea;
	
	public UndoCommand(JTextArea textArea) {
		this.textArea = textArea;
		this.textArea.getDocument().addUndoableEditListener(manager);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
			if(manager.canUndo()) {
				manager.undo();
			}
	}
	
	public UndoManager getManager() {
		return manager;
	}
}

