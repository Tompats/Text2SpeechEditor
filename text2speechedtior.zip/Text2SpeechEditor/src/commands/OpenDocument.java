package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Scanner;

import javax.swing.Icon;
import javax.swing.JFileChooser;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.FileView;

import java.util.ArrayList;
import java.util.Date;


import model.Document;
import model.Line;

public class OpenDocument implements ActionListener, Cloneable {

	private JFileChooser chooser = new JFileChooser();
	private StringBuilder sb = new StringBuilder();
	private JTextArea textArea;
	private Document currentDocument;
	private File file;
	private Scanner input;
	private boolean cancel = false;
	private ReplayManager replayManager;
	private boolean flag = false;
	

	public OpenDocument(JTextArea textArea,Document currentDocument,ReplayManager replayManager) {
		this.textArea=textArea;
		this.currentDocument=currentDocument;
		this.replayManager = replayManager;
	}
	
	public void createWordsArrayList(){
		ArrayList<Line> lines = new ArrayList<Line>();
		String getTexts = sb.toString();
		String[] linesArray = getTexts.split("\n");
		String[] wordsArray;
		for(int i=0;i<linesArray.length;i++) {
			wordsArray=linesArray[i].split(" ");
			Line line = new Line();
			line.setWords(wordsArray);
			lines.add(line);
			//System.out.println(line);
		}
		
		currentDocument.setLines(lines);
		System.out.println(currentDocument.getLines());
	}
	
	public void setDocumentDetails()throws Exception{
		Path path = FileSystems.getDefault().getPath(new String()).toAbsolutePath();
		BasicFileAttributes attr = Files.readAttributes(path, BasicFileAttributes.class);
		long creationDate = attr.creationTime().toMillis();
		Date creationDateToDate = new Date(creationDate);
		currentDocument.setDateCreated(creationDateToDate);
		long lastModDate = file.lastModified();
		Date lastModToDate = new Date(lastModDate);
		currentDocument.setDateSaved(lastModToDate);
		String filename = file.getName();
		String title = filename.substring(0, filename.lastIndexOf('.'));
		currentDocument.setTitle(title);
		String author  = System.getProperty("user.name");
		currentDocument.setAuthor(author);
	}
	
	public void pickFile() throws Exception{
		if (chooser.showOpenDialog(textArea) == JFileChooser.APPROVE_OPTION) {
			file = chooser.getSelectedFile();
			setDocumentDetails();
			//createString();
		}
		else {
			cancel = true;
		}
	}
	public void filterFile() {
		FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
		chooser.setAcceptAllFileFilterUsed(false);
		chooser.setFileFilter(filter);
	}
	
	public void editTextArea() {
		textArea.setText(null);
		textArea.append(sb.toString());
		sb.delete(0, sb.length());
	}
	public void editChooser() {
		chooser.setDialogTitle("Open a file");
		chooser.setFileView(new FileView(){
            public Icon getIcon(File f){
                return FileSystemView.getFileSystemView().getSystemIcon(f);
            }
        });
	}
	
	
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
	
	public void createString() throws FileNotFoundException {
		if (file!=null) {
			input = new Scanner(file);
			while(input.hasNext()) {
				sb.append(input.nextLine() + "\n");
			}
			input.close();
		}
	}
	
	public void actionPerformed(ActionEvent e) {
		try {
			if(!flag) {
				editChooser();
				filterFile();
				pickFile();
				if(cancel == false) {
					createString();
					
					createWordsArrayList();
					editTextArea();
					replayManager.setArray((ActionListener) clone());
				}
				else {
					cancel = false;
				}
			}
			else {
				if(cancel == false) {
					createString();
					
					createWordsArrayList();
					editTextArea();
					
					flag = false;
					replayManager.setArray((ActionListener) clone());
				}
				else {
					flag = false;
					cancel = false;
				}
			}
		} 
		catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public File getFile() {
		return file;
	}

	public void setFlag() {
		flag  = true;
		
	}
	

}
