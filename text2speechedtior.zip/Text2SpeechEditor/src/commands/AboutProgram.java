package commands;


import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.io.File;
import java.awt.event.ActionListener;


public class AboutProgram implements ActionListener, Cloneable {

	private File aboutFile;
	private ReplayManager replayManager;



	public AboutProgram(ReplayManager replayManager) {
		this.replayManager = replayManager;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		executeHelpFile();
	}
	
	
	
	

	
	
	public void executeHelpFile() {
		try {
			aboutFile = new File("about.txt");
			if (aboutFile.exists()) {
	
				if (Desktop.isDesktopSupported()) {
					replayManager.setArray((ActionListener) clone());
					Desktop.getDesktop().open(aboutFile);
				} 
				else {
					System.out.println("Awt Desktop is not supported!");
				}
	
			} 
			else {
				 String current = null;
					try {
						current = new java.io.File( "." ).getCanonicalPath();
						aboutFile = new File(current);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
			}
			System.out.println("Done");
	
		} 
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 

}
