package commands;

import java.util.List;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;


public class ActionListenerTask {
	private ArrayList<ActionListener> replayCommandsArray;
	private ReplayManager replayManager;
	public ActionListenerTask(ReplayManager replayManager,ArrayList<ActionListener> replayCommandsArray) {
		this.replayManager = replayManager;
		this.replayCommandsArray=replayCommandsArray;
	}
	public SwingWorker<Integer, ActionListener> create() {
		return new SwingWorker<Integer,ActionListener>(){
		
	
			@Override
			public Integer doInBackground() throws Exception {
				int CommandsCounter = 0;
				for(int i=0;i<replayCommandsArray.size();i++) {
					publish(replayCommandsArray.get(i));
					CommandsCounter++;
				}
				return CommandsCounter;
			}
			
			@Override
			protected void process(List<ActionListener> array) {
				for(int i=0;i<array.size();i++) {
					
					if(array.get(i).getClass() == NewDocument.class) {
						JFrame frame = new JFrame("JOptionPane showMessageDialog component example");
				    	JOptionPane.showMessageDialog(frame,"Your document's details have been updated!");
				    	array.get(i).actionPerformed(null);
					}
					else if(array.get(i).getClass() == SaveDocument.class) {
						((SaveDocument) array.get(i)).setFlag();
						array.get(i).actionPerformed(null);
					}
					else if(array.get(i).getClass() == OpenDocument.class) {
						((OpenDocument) array.get(i)).setFlag();
						array.get(i).actionPerformed(null);
					}
					else {
						array.get(i).actionPerformed(null);
					}
				}
			}
			protected void done() {
				int CommandsCounter =0;
				try {
					CommandsCounter=get();
					
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				System.out.println("Finished with status "+CommandsCounter);
				replayManager.clear(CommandsCounter);
				System.out.println(replayManager.getArray());
			}
	};
}
}
	


