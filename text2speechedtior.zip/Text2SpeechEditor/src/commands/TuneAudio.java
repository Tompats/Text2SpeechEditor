package commands;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.Document;

public class TuneAudio implements ActionListener {
	
	private Document currentDocument;
	private String type;
	private int number;
	
	public TuneAudio(Document currentDocument,String type,int number) {
		this.currentDocument=currentDocument;
		this.type=type;
		this.number=number;
	}

	public void actionPerformed(ActionEvent e) {
		if(type.equals("Pitch")) {
			currentDocument.setPitch(number);		
		}
		else if(type.equals("Rate")) {
			currentDocument.setRate(number);
		}
		else if(type.equals("Volume")) {
			currentDocument.setVolume(number);
		}
	}
}
