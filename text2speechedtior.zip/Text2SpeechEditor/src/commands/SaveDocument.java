package commands;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;

import javax.swing.Icon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileSystemView;
import javax.swing.filechooser.FileView;

import model.Document;



public class SaveDocument implements ActionListener, Cloneable {
	private File fileToSave;
	private Document currentDocument;
	private JTextArea textArea;
	private JFileChooser fileChooser = new JFileChooser();
	private ReplayManager replayManager;
	private boolean flag = false;
	
	public SaveDocument(JTextArea textArea,Document currentDocument,ReplayManager replayManager) {
		this.currentDocument=currentDocument;
		this.textArea = textArea;
		this.replayManager = replayManager;
	}
	  
	 
	  
	  public void checkFileType() {
	        if(!fileToSave.getName().toLowerCase().endsWith(".txt")) {
	            fileToSave = new File(fileToSave.getParentFile(), fileToSave.getName() + ".txt");
	          }
	   }
	  
	  public void grabFile() throws Exception{
	      int userSelection = fileChooser.showSaveDialog(textArea);
	      if(userSelection == JFileChooser.APPROVE_OPTION){
	    	  fileToSave = fileChooser.getSelectedFile();
	       }
	   }
	  
	  public void writeFile() throws Exception {
		  FileOutputStream outputStream = new FileOutputStream(fileToSave.getAbsolutePath());
		  String s = currentDocument.getText();
		  outputStream.write(s.getBytes()); 
		  outputStream.close();
	  }
	  public void editChooser() {
		  fileChooser.setDialogTitle("Specify a file to save");
		  fileChooser.setFileView(new FileView(){
	            public Icon getIcon(File f){
	                return FileSystemView.getFileSystemView().getSystemIcon(f);
	            }
	        });
		}
	 
	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if(!flag) {
				editChooser();
				grabFile();
				checkFileType();
				writeFile();
				JFrame frame = new JFrame("JOptionPane showMessageDialog component example");
		    	JOptionPane.showMessageDialog(frame,"File saved to: " + fileToSave.getAbsolutePath());
				replayManager.setArray((ActionListener)clone());
			}
			else {
				writeFile();
				JFrame frame = new JFrame("JOptionPane showMessageDialog component example");
		    	JOptionPane.showMessageDialog(frame,"File saved to: " + fileToSave.getAbsolutePath());
				replayManager.setArray((ActionListener)clone());
				flag = false;
			}
		} 
		catch (Exception e1) {
			//e1.printStackTrace();
		}
	}
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
	public void setFlag() {
		flag =true;
	}
	
	public File getFile() {
		return fileToSave;
	}

}
