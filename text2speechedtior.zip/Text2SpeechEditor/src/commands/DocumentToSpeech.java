package commands;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Document;

public class DocumentToSpeech implements ActionListener, Cloneable {
	private Document currentDocument;
	private ReplayManager replayManager;
	
	public DocumentToSpeech(Document currentDocument, ReplayManager replayManager) {
		this.currentDocument = currentDocument;
		this.replayManager = replayManager;
	}

	public void actionPerformed(ActionEvent e) {
		try {
			replayManager.setArray((ActionListener) clone());
		} catch (CloneNotSupportedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		currentDocument.playContents();
	}
	
	public Object clone() throws CloneNotSupportedException{ 
        return super.clone(); 
    } 
}

