package commands;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.undo.UndoManager;

import model.Document;

public class CommandsFactory {
	private JTextArea textArea;
	private Document currentDocument;
	private String title;
	private String author;
	private JFrame messageFrame;
	private UndoManager undoManager = null;
	private int line;
	private int pitch;
	private int rate;
	private int volume;
	private ReplayManager replayManager;
	
	public CommandsFactory(Document currentDocument) {
		this.currentDocument = currentDocument;
		replayManager = new ReplayManager(currentDocument);
	}
	//////////////COMMANDS//////////////////
	public ActionListener createCommand(String type) {
		if(type.equals("New Document")) {
			NewDocument test = new NewDocument(currentDocument,title,author,messageFrame,textArea,replayManager);
			return  test;
		}
		else if(type.equals("Exit")) {
			ExitDocument exiter = new ExitDocument();
			return exiter;
		}
		else if(type.equals("New Window")) {
			NewWindow windower = new NewWindow(replayManager);
			return windower;
		}
		else if(type.equals("Open")) {
			OpenDocument opener = new OpenDocument(textArea, currentDocument, replayManager);
			return opener;
		}
		else if(type.equals("Save As")) {
			SaveDocument saver = new SaveDocument(textArea,currentDocument,replayManager);
			return saver;
		}
		else if(type.equals("Help")) {
			HelpViewer helpViewer = new HelpViewer(replayManager);
			return helpViewer;
		}
		else if(type.equals("About")) {
			AboutProgram AboutProgram = new AboutProgram(replayManager);
			return AboutProgram;
		}
		else if(type.equals("Edit Document")) {
			EditDocument editor = new EditDocument(textArea,currentDocument);
			return editor;
		}
		else if(type.equals("Print Document")) {
			PrintDocument printer = new PrintDocument(textArea,replayManager);
			return printer;
		}
		else {
			return  null;
		}
		
	}
	
	public ActionListener createEditCommand(String type) {
		
		if(type.equals("Undo")) {
			UndoCommand undoer = new UndoCommand(textArea);
			undoManager = undoer.getManager();
			return undoer;
		}
		else if(type.equals("Redo")) {
			RedoCommand redoer = new RedoCommand(undoManager);
			return redoer;
		}
		else if(type.equals("Delete")) {
			DeleteCommand deleter = new DeleteCommand(textArea);
			return deleter;
		}
		else if(type.equals("Select All")) {
			SelectAllCommand selecter = new SelectAllCommand(textArea);
			return selecter;
		}
		return null;	
	}
	
	public ActionListener createZoomCommand(String type) {
		
		if(type.equals("Zoom In")) {
			ZoomIn zoomIn = new ZoomIn(textArea,replayManager);
			return zoomIn;
		}
		else if(type.equals("Zoom Out")) {
			ZoomOut zoomOut = new ZoomOut(textArea,replayManager);
			return zoomOut;
		}
		else if(type.equals("Restore Zoom")) {
			ZoomRestore zoomRestorer = new ZoomRestore(textArea,replayManager);
			return zoomRestorer;
		}
		return null;
	}
	
	public ActionListener createSpeechCommands(String type) {
		if(type.equals("Play")) {
			DocumentToSpeech player = new DocumentToSpeech(currentDocument,replayManager);
			return player;
		}
		else if(type.equals("Play Reverse")) {
			ReversedDocumentToSpeech reversedPlayer = new ReversedDocumentToSpeech(currentDocument,replayManager);
			return reversedPlayer;
		}
		else if(type.equals("Play Line")) {
			LineToSpeech linePlayer = new LineToSpeech(currentDocument,line,replayManager);
			return linePlayer;
		}
		else if(type.contentEquals("Play Reversed Line")) {
			ReversedLineToSpeech reversedLinePlayer = new ReversedLineToSpeech(currentDocument,line,replayManager);
			return reversedLinePlayer;
		}
		else if(type.equals("Play Encoded")) {
			EncodedDocumentToSpeech encodedPlayer = new EncodedDocumentToSpeech(currentDocument,replayManager);
			return encodedPlayer;
		}
		else if(type.equals("Play Encoded Line")) {
			EncodedLineToSpeech encodedPlayer = new EncodedLineToSpeech(currentDocument,line,replayManager);
			return encodedPlayer;
		}
		return null;
	}
	
	public ActionListener createEncodeCommand(String type) {
		if(type.equals("Rot-13")) {
			TuneEncoding tuner = new TuneEncoding(currentDocument,type,replayManager);
			return tuner;
		}
		else if(type.equals("AtBash")) {
			TuneEncoding tuner = new TuneEncoding(currentDocument,type,replayManager);
			return tuner;
		}
		return null;
	}
	
	
	public ActionListener createMixerCommand(String type) {
        if(type.equals("Pitch")) {
            TuneAudio tuner = new TuneAudio(currentDocument,type,pitch);
            return tuner;
        }
        else if(type.equals("Rate")) {
            TuneAudio tuner = new TuneAudio(currentDocument,type,rate);
            return tuner;
        }
        else if(type.equals("Volume")) {
            TuneAudio tuner = new TuneAudio(currentDocument,type,volume);
            return tuner;
        }
        return null;
    }
	public ActionListener createReplayCommand(String type) {
		if(type.equalsIgnoreCase("Replay Commands")) {
			ReplayCommand commandReplayer  = new ReplayCommand(replayManager);
			return commandReplayer;
		}
		return null;
	}
	
	//////////////STUFF//////////////////
	public void setTextArea(JTextArea text) {
		textArea=text;
	}
	public void setCurrentDocument(Document current) {
		currentDocument = current;
	}
	public void setNewDocTitle(String title) {
		this.title = title;
	}
	public void setNewDocAuthor(String author) {
		this.author = author;
	}
	public void setNewDocFrame(JFrame messageFrame) {
		this.messageFrame = messageFrame;
	}
	public void setReplayManager(ReplayManager replayManager) {
		// TODO Auto-generated method stub
		
	}
	public void setLineNumber(int line) {
		this.line = line;
		
	}
	public void setPitchLevel(int pitch) {
		this.pitch = pitch;
	}
	public void setRateLevel(int rate) {
		this.rate = rate;
	}
	public void setVolumeLevel(int volume) {
		this.volume = volume;
	}
}