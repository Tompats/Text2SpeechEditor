package model;

import java.util.ArrayList;
import java.util.Date;

import encodingstrategies.EncodingStrategy;
import text2speechapis.TextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;

public class Document {
	private ArrayList<Line> lines = new ArrayList<Line>();
	private TextToSpeechAPI audioManager;
	private String title;
	private String author;
	private Date dateCreated;
	private Date dateSaved;
	private EncodingStrategy encodingStrategy;
	
	
	public Document() {
		
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public void setNewDateCreated() {
		dateCreated = new Date();
		
	}
	public void setNewDateSaved() {
		dateSaved = new Date();
		
	}
	public void setDateCreated(Date date) {
		dateCreated = date;
		
	}
	public void setDateSaved(Date date) {
		dateSaved = date;
		
	}
	
	
	
	public String toString() {
		String s ="Title: " + title + "\nAuthor: " + author + "\nDate Created: "+dateCreated + "\nLast date of modification: " + dateSaved ;
		System.out.println(lines);
		return s;
	}
	
	
	
	public String getText() {
		String text="";
		for(int i=0;i<lines.size(); i++) {
			if(i==lines.size()-1) {
				text += lines.get(i).toString();
			}
			else {
			text += lines.get(i).toString() + "\n";
			}
		}
		return text;
	}
	
	
	
	public void setLines(ArrayList<Line> lines) {
			this.lines=lines;
		
	}
	
	
	
	public void deleteLinesArrayList() {
		lines = new ArrayList<Line>();
	}
	
	
	
	public void setSpeechAPI(TextToSpeechAPIFactory factory) {
		audioManager = factory.createTTSAPI("Real");
		//audioManager.setRate(230);
	}
	
	public void setFakeSpeechAPI(TextToSpeechAPIFactory factory) {
		audioManager = factory.createTTSAPI("Fake");
		//audioManager.setRate(230);
	}
	
	
	
	public void playContents() {
		
		for(int i=0;i<lines.size(); i++) {
			
			lines.get(i).SetSpeechAPI(audioManager);
			
			lines.get(i).playLine();
			
		}
	}
	
	
	
	public void playReverseContents() {
		for(int i=lines.size()-1;i>=0; i--) {
			lines.get(i).SetSpeechAPI(audioManager);
			lines.get(i).playReverseLine();
		}
		
	}
	
	
	
	public void playEncodedContents() {
		for(int i=0;i<lines.size(); i++) {
			lines.get(i).SetSpeechAPI(audioManager);
			lines.get(i).tuneEncodingStrategy(encodingStrategy);
			lines.get(i).playEncodedLine();
		}
	}
	
	
	public void playLine(int line) {
		lines.get(line).SetSpeechAPI(audioManager);
		lines.get(line).playLine();
	}
	
	
	
	public void playReverseLine(int line) {
		lines.get(line).SetSpeechAPI(audioManager);
		lines.get(line).playReverseLine();
	}
	
	
	
	public void playEncodedLine(int line) {
		lines.get(line).SetSpeechAPI(audioManager);
		lines.get(line).tuneEncodingStrategy(encodingStrategy);
		lines.get(line).playEncodedLine();
	}
	
	
	
	public void tuneEncodingStrategy(EncodingStrategy encodingStrategy) {
		this.encodingStrategy = encodingStrategy;
	}
	
	
	public void setPitch(int i) {
		audioManager.setPitch(i);
	}
	
	
	
	public void setVolume(int i) {
		audioManager.setVolume(i);
	}
	
	
	public void setRate(int i) {
		audioManager.setRate(i);
	}
	public ArrayList<Line> getLines(){
		return lines;
	}
	public String getAuthor() {
		return author;
	}
	public String getTitle() {
		return title;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public Date getDateSaved() {
		return dateSaved;
	}
	public String arrayToText() {
		String s="";
		for(int i=0;i<lines.size(); i++) {
			s += lines.get(i).toString() + "\n";
		}
		return s;
	}
	public TextToSpeechAPI getManager() {
		return audioManager;
	}
	public EncodingStrategy getEncodingStrategy() {
		return encodingStrategy;
	}
	
}
