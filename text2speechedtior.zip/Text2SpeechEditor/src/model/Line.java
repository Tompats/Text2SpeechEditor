package model;

import java.util.ArrayList;


import encodingstrategies.EncodingStrategy;
import text2speechapis.TextToSpeechAPI;
	

public class Line {
	private ArrayList<String> words = new ArrayList<String>();
	//private Voice voice;
	//private VoiceManager voiceManager;
	private TextToSpeechAPI audioManager;
	private EncodingStrategy encodingStrategy;
	
	public Line() {
		
	}
	
	public void playLine() {
		audioManager.play(toString());
		
	}
	public void playReverseLine() {
		audioManager.play(toReverseString());
	}
	public void playEncodedLine() {
		try {
		String encodedText = encodingStrategy.encode(toString());
		audioManager.play(encodedText);
		}
		catch(Exception e) {
			
		}
	}
	public void tuneEncodingStrategy(EncodingStrategy encodingStrategy) {
		this.encodingStrategy = encodingStrategy;
	}
	
	public void setWords(String[] words) {
		//this.words=words;
		for(int i=0;i<words.length;i++) {
			this.words.add(words[i]);
		}
	}
	public String toString() {
		String s="";
		for(int i=0;i<words.size();i++) {
			if(i==words.size()-1) {
				s+=words.get(i);
			}
			else {
				s+=words.get(i) + " ";
			}
		}
		return s;
	}
	public String toReverseString() {
		String text = "";
		for(int i=words.size()-1;i>=0;i--) {
			text += words.get(i) + " ";
		}
		return text;
	}
	public void SetSpeechAPI(TextToSpeechAPI audioManager) {
		this.audioManager = audioManager;
	}
	public TextToSpeechAPI getManager() {
		return audioManager;
	}
}
