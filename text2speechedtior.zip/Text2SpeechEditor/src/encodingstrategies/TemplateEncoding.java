package encodingstrategies;

public abstract class TemplateEncoding implements EncodingStrategy {

	
	
	public TemplateEncoding() {
		
	}
	
	
	@Override
	public String encode(String text) {
		// TODO Auto-generated method stub
		return null;
	}
	abstract char mapCharacter(char letter);
}
