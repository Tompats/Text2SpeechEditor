package encodingstrategies;

public class AtBashEncoding extends TemplateEncoding {

	
	
	private String text;



	public AtBashEncoding() {
		
	}
	
	
	
	@Override
	public String encode(String text) {
		char chars[] = text.toCharArray();
		String encodedText="";
		for(int i=0;i<chars.length;i++) {
			encodedText+=mapCharacter(chars[i]);
		}
		setText(encodedText);
		return encodedText;
	}
	
	private void setText(String encodedText) {
		text = encodedText;
		
	}



	@Override
	char mapCharacter(char letter) {
		if (letter >= 'a' && letter <= 'z') {
			letter = (char)('a'+'z'-letter);
        } 
		else if (letter >= 'A' && letter <= 'Z') {
			letter = (char)('A'+'Z'-letter);
        }
		return letter;
	}



	public String getText() {
		// TODO Auto-generated method stub
		return text;
	}

}
