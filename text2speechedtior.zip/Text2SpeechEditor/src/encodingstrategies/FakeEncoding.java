package encodingstrategies;

public class FakeEncoding extends TemplateEncoding {

	
	
	public FakeEncoding() {
		
	}
	
	@Override
	char mapCharacter(char letter) {
		return letter;
	}
	@Override
	public String encode(String text) {
		char chars[] = text.toCharArray();
		String encodedText="";
		for(int i=0;i<chars.length;i++) {
			encodedText+=mapCharacter(chars[i]);
		}
		return encodedText;
	}

}
