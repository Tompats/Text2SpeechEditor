package encodingstrategies;

public class StrategiesFactory {
	
	private EncodingStrategy encoder;
	
	public StrategiesFactory(){
		
	}
	
	public EncodingStrategy createStrategy(String type) {
		if(type.equals("Rot-13")) {
			encoder = new Rot13Encoding() ;
			return encoder;
		}
		else if(type.equals("AtBash")) {
			encoder = new AtBashEncoding() ;
			return encoder;
		}
		return null;
	}
}
