package encodingstrategies;

public class Rot13Encoding extends TemplateEncoding {

	
	
	private String text="";
	public Rot13Encoding() {
		
	}
	@Override
	public String encode(String text) {
		char chars[] = text.toCharArray();
		String encodedText="";
		for(int i=0;i<chars.length;i++) {
			encodedText+=mapCharacter(chars[i]);
		}
		setText(encodedText);
		return encodedText;
	}
	
	private void setText(String encodedText) {
		this.text = encodedText;
		
	}
	public String getText() {
		return text;
	}
	
	@Override
	char mapCharacter(char letter) {
		if (letter >= 'a' && letter <= 'z') {
            if (letter > 'm') {
                letter -= 13;
            } 
            else {
                letter += 13;
            }
        } else if (letter >= 'A' && letter <= 'Z') {
            if (letter > 'M') {
                letter -= 13;
            } 
            else {
                letter += 13;
            }
        }
		return letter;
	}

}
