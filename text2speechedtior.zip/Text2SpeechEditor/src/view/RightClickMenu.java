package view;


import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.JTextComponent;
import javax.swing.text.TextAction;

import commands.CommandsFactory;

public class RightClickMenu {
	private JPopupMenu popupMenu = new JPopupMenu();
	private CommandsFactory factor;
	
	
	
	public RightClickMenu(CommandsFactory factor) {
		this.factor = factor;
		init();
	}
	
	public void setPopup(JTextComponent... components){
	      if(components == null){
	          return;
	      }
	      for (JTextComponent tc : components) {
	          tc.setComponentPopupMenu(popupMenu);
	      }
	}


		

		private void init() {
			addAction(new DefaultEditorKit.CutAction(), KeyEvent.VK_X, "Cut" );
		    addAction(new DefaultEditorKit.CopyAction(), KeyEvent.VK_C, "Copy" );
		    addAction(new DefaultEditorKit.PasteAction(), KeyEvent.VK_V, "Paste" );
		    putMenus();
		}

		private void addAction(TextAction action, int key, String text) {
		    action.putValue(AbstractAction.ACCELERATOR_KEY, KeyStroke.getKeyStroke(key, InputEvent.CTRL_DOWN_MASK));
		    action.putValue(AbstractAction.NAME, text);
		    popupMenu.add(new JMenuItem(action));
		}
		
		
		
		public void putMenus() {
		JMenuItem UndoItem = new JMenuItem("Undo");
		KeyStroke keyStrokeUndo = KeyStroke.getKeyStroke(KeyEvent.VK_Z, KeyEvent.CTRL_DOWN_MASK);
		UndoItem.setAccelerator(keyStrokeUndo);
		UndoItem.addActionListener(factor.createEditCommand("Undo"));
		popupMenu.add(UndoItem);
		
		
		
		JMenuItem RedoItem = new JMenuItem("Redo");
		KeyStroke keyStrokeRedo = KeyStroke.getKeyStroke(KeyEvent.VK_Y, KeyEvent.CTRL_DOWN_MASK);
		RedoItem.setAccelerator(keyStrokeRedo);
		RedoItem.addActionListener(factor.createEditCommand("Redo"));
		popupMenu.add(RedoItem);
		
		
		
		JMenuItem DeleteItem = new JMenuItem("Delete");
		KeyStroke keyStrokeDelete = KeyStroke.getKeyStroke("DELETE");
		DeleteItem.setAccelerator(keyStrokeDelete);
		DeleteItem.addActionListener(factor.createEditCommand("Delete"));
		popupMenu.add(DeleteItem);
		
		
		
		JMenuItem SelectAllItem = new JMenuItem("Select All");
		KeyStroke keyStrokeSelectAll = KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.CTRL_DOWN_MASK);
		SelectAllItem.setAccelerator(keyStrokeSelectAll);
		SelectAllItem.addActionListener(factor.createEditCommand("Select All"));
		popupMenu.add(SelectAllItem);
	}

}
