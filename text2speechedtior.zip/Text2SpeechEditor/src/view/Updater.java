package view;

import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import commands.CommandsFactory;

public class Updater implements DocumentListener {
	
	private JTextArea textArea;
	private StatusBar statusBar;
	private CommandsFactory factor;

	public Updater(JTextArea textArea, StatusBar statusBar, CommandsFactory factor) {
		this.textArea = textArea;
		this.statusBar = statusBar;
		this.factor = factor;
	}
	
	@Override
	public void insertUpdate(DocumentEvent documentEvent)
	{
		int lineCounter = textArea.getLineCount();
	    int charCounter = textArea.getText().length();
	    statusBar.setMessage(String.valueOf(lineCounter),String.valueOf(charCounter));
	    factor.createCommand("Edit Document").actionPerformed(null);
	}

	@Override
	public void removeUpdate(DocumentEvent documentEvent)
	{
	   	int lineCounter = textArea.getLineCount();
	   	int charCounter = textArea.getText().length();
	   	statusBar.setMessage(String.valueOf(lineCounter),String.valueOf(charCounter));
	    factor.createCommand("Edit Document").actionPerformed(null);
	}

	@Override
	public void changedUpdate(DocumentEvent documentEvent)
   {
	   	int lineCounter = textArea.getLineCount();
	   	int charCounter = textArea.getText().length();
	   	statusBar.setMessage(String.valueOf(lineCounter),String.valueOf(charCounter));
	    factor.createCommand("Edit Document").actionPerformed(null);
   }


}
