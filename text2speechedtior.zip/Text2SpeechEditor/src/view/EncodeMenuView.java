package view;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

import commands.CommandsFactory;

public class EncodeMenuView {
	
	private JMenu EncodeMenu;
	private CommandsFactory factor;
	
	public EncodeMenuView(JMenu EncodeMenu,CommandsFactory factor) {
		this.EncodeMenu=EncodeMenu;
		this.factor=factor;
		init();
	}

	public void init() {
		JMenuItem EncodeAtBashItem = new JMenuItem("AtBash");
		EncodeAtBashItem.addActionListener(factor.createEncodeCommand("AtBash"));
		EncodeMenu.add(EncodeAtBashItem);
		
		JMenuItem EncodeRot13Item = new JMenuItem("Rot-13");
		EncodeRot13Item.addActionListener(factor.createEncodeCommand("Rot-13"));
		EncodeMenu.add(EncodeRot13Item);
		
	}
}
