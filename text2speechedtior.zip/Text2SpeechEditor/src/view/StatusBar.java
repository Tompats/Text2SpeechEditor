package view;

import java.awt.Dimension;

import javax.swing.JLabel;

@SuppressWarnings("serial")
public class StatusBar extends JLabel {
	/** Creates a new instance of StatusBar */
    public StatusBar(int lineCounter, int rowCounter) {
        super();
        super.setPreferredSize(new Dimension(100, 16));
        
        setMessage(String.valueOf(lineCounter),String.valueOf(rowCounter));
    }
     
    public void setMessage(String lines, String chars) {
        setText(" Lines: "+lines+" , "+"Chars: "+chars);        
    }
}