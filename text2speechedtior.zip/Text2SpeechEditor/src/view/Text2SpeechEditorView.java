package view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import java.awt.BorderLayout;
import java.awt.Color;
import commands.CommandsFactory;
import model.Document;
import text2speechapis.TextToSpeechAPIFactory;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.Utilities;

@SuppressWarnings("unused")
public class Text2SpeechEditorView {

	private JFrame frame;
	private JTextArea textArea;
	private Document currentDocument = new Document();
	private TextToSpeechAPIFactory speechFactory = new TextToSpeechAPIFactory();
	private CommandsFactory factor;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Text2SpeechEditorView window = new Text2SpeechEditorView();
					window.initialize();
					//window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Text2SpeechEditorView() {
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */

	public void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 737, 443);
		frame.setTitle("Text2SpeechEditor\r\n");
		ImageIcon programIcon = new ImageIcon("Text2Speech.jpg");
		frame.setIconImage(programIcon.getImage());
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		textArea = new JTextArea();
		frame.getContentPane().add(textArea, BorderLayout.CENTER);
		JScrollPane sp = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.getContentPane().add(sp);
		Font font = textArea.getFont();
		float size = font.getSize() + 16.0f;
		textArea.setFont( font.deriveFont(size) );
		factor = new CommandsFactory(currentDocument);
		VolumeController ns = new VolumeController(factor);
		factor.setTextArea(textArea);
		factor.setCurrentDocument(currentDocument);
		currentDocument.setSpeechAPI(speechFactory);
		int lineCounter = textArea.getLineCount();
		int charCounter = textArea.getText().length();
		StatusBar statusBar = new StatusBar(lineCounter,charCounter);
		frame.add(statusBar, java.awt.BorderLayout.SOUTH);
		textArea.getDocument().addDocumentListener(new Updater(textArea,statusBar, factor));
		RightClickMenu rightClicker = new RightClickMenu(factor);
		rightClicker.setPopup(textArea);
		
	
		
		JMenuBar menuBar = new JMenuBar();
		
		
		JMenu FileMenu = new JMenu("File");
		menuBar.add(FileMenu);
		FileMenuView fileMenuViewer = new FileMenuView(FileMenu,factor);
		
		JMenu EditMenu = new JMenu("Edit");
		menuBar.add(EditMenu);
		EditMenuView editMenuViewer = new EditMenuView(EditMenu,factor);
			
		JMenu EncodeMenu = new JMenu("Encode");
		menuBar.add(EncodeMenu);
		EncodeMenuView encodeMenuViewer = new EncodeMenuView(EncodeMenu,factor);
		
		JMenu SpeechMenu = new JMenu("Speech");
		menuBar.add(SpeechMenu);
		SpeechMenuView speechMenuViewer = new SpeechMenuView(SpeechMenu,factor,textArea);
		
		JMenu ReplayMenu = new JMenu("Replay");
		JMenuItem ReplayItem = new JMenuItem("Replay Commands");
		ReplayItem.addActionListener(factor.createReplayCommand("Replay Commands"));
		ReplayMenu.add(ReplayItem);
		menuBar.add(ReplayMenu);
		
		JMenu ViewMenu = new JMenu("View");
		menuBar.add(ViewMenu);
		ViewMenuView viewMenuViewer = new ViewMenuView(ViewMenu,factor);
		
		JMenu HelpMenu = new JMenu("Help");
		menuBar.add(HelpMenu);
		HelpMenuView helpMenuViewer = new HelpMenuView(HelpMenu,factor);
			
		ImageIcon speakerIcon = new ImageIcon("speaker.jpg");
		JButton btnNewButton = new JButton(speakerIcon);
		btnNewButton.setForeground(Color.LIGHT_GRAY);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		menuBar.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton.setEnabled(false);
				ns.setButton(btnNewButton);
				ns.initialize();
			}
		});		
		frame.setJMenuBar(menuBar);	
		frame.setVisible(true);
	}
	
	public Document getCurrentDocument() {
		return currentDocument;
	}
	public JTextArea getTextArea() {
		return textArea;
	}
	
}
