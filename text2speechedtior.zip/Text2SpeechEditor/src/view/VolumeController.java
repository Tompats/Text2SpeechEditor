package view;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.event.ChangeListener;
import commands.CommandsFactory;

import javax.swing.event.ChangeEvent;

public class VolumeController {

	private JFrame frame;
	private CommandsFactory factor;
	private int volume_start=10;
	private int rate_start=120;
	private int pitch_start=100;
	private JButton button;
	
	public VolumeController(CommandsFactory factor) {
		this.factor=factor;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		
		frame = new JFrame();
		frame.setTitle("Mixer\r\n");
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 419, 244);
		//frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {

			@Override
	        public void windowClosing(WindowEvent windowEvent) {
	        	button.setEnabled(true);
	        	frame.dispose();
	        }
		});
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		ImageIcon speakerIcon = new ImageIcon("speaker.jpg");
		frame.setIconImage(speakerIcon.getImage());
		
		JSlider slider = new JSlider(0,10,volume_start);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				int volume=slider.getValue();
				factor.setVolumeLevel(volume);
				factor.createMixerCommand("Volume").actionPerformed(null);
				setNumber(volume,pitch_start,rate_start);
			}
		});
		slider.setBackground(Color.LIGHT_GRAY);
		slider.setBounds(193, 11, 200, 26);
		frame.getContentPane().add(slider);
		
		JSlider slider_1 = new JSlider(30,330,rate_start);
		slider_1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				int rate=slider_1.getValue();
				factor.setRateLevel(rate);
				factor.createMixerCommand("Rate").actionPerformed(null);
				setNumber(volume_start,pitch_start,rate);
			}
		});
		slider_1.setBackground(Color.LIGHT_GRAY);
		slider_1.setBounds(193, 90, 200, 26);
		frame.getContentPane().add(slider_1);
		
		JSlider slider_2 = new JSlider(0,1000,pitch_start);
		slider_2.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				int pitch=slider_2.getValue();
				factor.setPitchLevel(pitch);
				//System.out.println(pitcher);
				factor.createMixerCommand("Pitch").actionPerformed(null);
				setNumber(volume_start,pitch,rate_start);
			}
		});
		slider_2.setBackground(Color.LIGHT_GRAY);
		slider_2.setBounds(193, 168, 200, 26);
		frame.getContentPane().add(slider_2);
		
		JLabel lblNewLabel = new JLabel("Volume");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 103, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblSpeechRate = new JLabel("Speech Rate");
		lblSpeechRate.setHorizontalAlignment(SwingConstants.CENTER);
		lblSpeechRate.setBounds(10, 90, 103, 14);
		frame.getContentPane().add(lblSpeechRate);
		
		JLabel lblPitch = new JLabel("Pitch");
		lblPitch.setHorizontalAlignment(SwingConstants.CENTER);
		lblPitch.setBounds(10, 168, 103, 14);
		frame.getContentPane().add(lblPitch);
		
		frame.setVisible(true);
	}
	public void setNumber(int volume,int pitch,int rate) {
		volume_start = volume;
		rate_start = rate;
		pitch_start = pitch;
	}
	public void setButton(JButton button) {
		this.button = button;
	}
}
