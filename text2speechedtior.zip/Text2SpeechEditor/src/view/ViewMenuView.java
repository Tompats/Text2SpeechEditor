package view;

import java.awt.event.KeyEvent;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import commands.CommandsFactory;

public class ViewMenuView {
	
	private JMenu ViewMenu;
	private CommandsFactory factor;
	
	public ViewMenuView(JMenu ViewMenu,CommandsFactory factor) {
		this.ViewMenu=ViewMenu;
		this.factor=factor;
		init();
	}
	
	public void init() {
		JMenu ZoomMenu = new JMenu("Zoom");
		ViewMenu.add(ZoomMenu);
		//////Zoom-Items///////////
			JMenuItem ZoomInItem = new JMenuItem("Zoom In");
			ZoomInItem.addActionListener(factor.createZoomCommand("Zoom In"));
			KeyStroke keyStrokeToZoomIn = KeyStroke.getKeyStroke(KeyEvent.VK_EQUALS, KeyEvent.CTRL_DOWN_MASK);
			ZoomInItem.setAccelerator(keyStrokeToZoomIn);
			ZoomMenu.add(ZoomInItem);
			
			JMenuItem ZoomOutItem = new JMenuItem("Zoom Out");
			ZoomOutItem.addActionListener(factor.createZoomCommand("Zoom Out"));
			KeyStroke keyStrokeToZoomOut = KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, KeyEvent.CTRL_DOWN_MASK);
			ZoomOutItem.setAccelerator(keyStrokeToZoomOut);
			ZoomMenu.add(ZoomOutItem);
			
			JMenuItem RestoreZoomItem = new JMenuItem("Restore Zoom");
			RestoreZoomItem.addActionListener(factor.createZoomCommand("Restore Zoom"));
			ZoomMenu.add(RestoreZoomItem);
	}

}
