package view;


import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import commands.CommandsFactory;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class LinePickerView {
	private JFrame frame;
	private JTextField textField;
	private CommandsFactory factor;
	private String type;
	private JTextArea textArea;
	
	
	public LinePickerView(CommandsFactory factor, JTextArea textArea, String type) {
		this.factor = factor;
		this.textArea = textArea;
		this.type = type;
	}
	

	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 300, 200);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		ImageIcon programIcon = new ImageIcon("Text2Speech.jpg");
		frame.setIconImage(programIcon.getImage());
		frame.setResizable(false);
		textField = new JTextField();
		textField.setColumns(10);
		textField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                String lineNumber=textField.getText();
                try {
	                int line = (Integer.parseInt(lineNumber)-1);
	                if(line>=0 && line<=textArea.getLineCount()) {
		                factor.setLineNumber(line);
		                factor.createSpeechCommands(type).actionPerformed(null);
		                frame.dispose();
	                }
	                else {
	                	Toolkit.getDefaultToolkit().beep();
	                	JOptionPane.showMessageDialog(null, "Incorrect line's number, please try again!");
	                }
                }catch(Exception e) {
                	Toolkit.getDefaultToolkit().beep();
                	JOptionPane.showMessageDialog(null, "Incorrect line's number, please try again!");
                }
            }

        });
		
		JLabel lblNewLabel = new JLabel("Give line's number\r\n");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(91)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(105)
							.addComponent(lblNewLabel)))
					.addContainerGap(117, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addGap(50)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(76, Short.MAX_VALUE))
		);
		frame.getContentPane().setLayout(groupLayout);
		frame.setVisible(true);
	}
}
