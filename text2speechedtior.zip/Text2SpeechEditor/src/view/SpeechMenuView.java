package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;

import commands.CommandsFactory;

public class SpeechMenuView {
	
	private JMenu SpeechMenu;
	private CommandsFactory factor;
	private JTextArea textArea;
	
	public SpeechMenuView(JMenu SpeechMenu,CommandsFactory factor, JTextArea textArea) {
		this.SpeechMenu=SpeechMenu;
		this.factor=factor;
		this.textArea = textArea;
		init();
	}
	
	public void init() {
		JMenu PlayDocumentMenu = new JMenu("Play Document");
		SpeechMenu.add(PlayDocumentMenu);
	
		
		JMenuItem PlayItem = new JMenuItem("Play");
		PlayItem.addActionListener(factor.createSpeechCommands("Play"));
		KeyStroke f5 = KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0);
		PlayItem.setAccelerator(f5);
		PlayDocumentMenu.add(PlayItem);
		
		JMenuItem ReverseItem = new JMenuItem("Play Reversed");
		ReverseItem.addActionListener(factor.createSpeechCommands("Play Reverse"));
		PlayDocumentMenu.add(ReverseItem);
		
		
		JMenuItem EncodedMenuItem = new JMenuItem("Play Encoded");
		EncodedMenuItem.addActionListener(factor.createSpeechCommands("Play Encoded"));
		PlayDocumentMenu.add(EncodedMenuItem);
		
		
		
		
		
		////////////////////////////////////////////////////////////////////////////////////
		
		
		JMenu PlayLineMenu = new JMenu("Play Line");
		SpeechMenu.add(PlayLineMenu);
		
		
		JMenuItem PlayLineItem = new JMenuItem("Play");
		PlayLineItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String type = "Play Line";
				LinePickerView linePicker = new LinePickerView(factor,textArea,type);
				linePicker.initialize();
			}
			
		});
		PlayLineMenu.add(PlayLineItem);
		
		JMenuItem ReverseLineItem = new JMenuItem("Play Reversed");
		ReverseLineItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String type = "Play Reversed Line";
				LinePickerView linePicker = new LinePickerView(factor,textArea,type);
				linePicker.initialize();
			}
			
		});
		PlayLineMenu.add(ReverseLineItem);
		
		
		JMenuItem EncodedLineMenuItem = new JMenuItem("Play Encoded");
		EncodedLineMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String type = "Play Encoded Line";
				LinePickerView linePicker = new LinePickerView(factor,textArea,type);
				linePicker.initialize();
			}
			
		});
		PlayLineMenu.add(EncodedLineMenuItem);
		
		
		
		
		
	}

}
