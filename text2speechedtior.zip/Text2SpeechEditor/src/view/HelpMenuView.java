package view;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

import commands.CommandsFactory;

public class HelpMenuView {
	
	private JMenu HelpMenu;
	private CommandsFactory factor;
	
	public HelpMenuView(JMenu HelpMenu,CommandsFactory factor) {
		this.HelpMenu=HelpMenu;
		this.factor=factor;
		init();
	}
	
	public void init(){
		JMenuItem AboutItem = new JMenuItem("About");
		AboutItem.addActionListener(factor.createCommand("About"));
		HelpMenu.add(AboutItem);
		
		JMenuItem ViewHelpItem = new JMenuItem("View Help");
		ViewHelpItem.addActionListener(factor.createCommand("Help"));
		HelpMenu.add(ViewHelpItem);
	}

}
