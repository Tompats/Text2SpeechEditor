package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import commands.CommandsFactory;

public class NewDocumentView {
	private JFrame frame;
	private JLabel lblNewLabel;
	private JLabel lblTitle;
	private JTextField textField;
	private JTextField textField_1;
	private CommandsFactory factor;
	
	
	public NewDocumentView(CommandsFactory factor) {
		this.factor = factor;
	}
	

	
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 491, 279);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		ImageIcon programIcon = new ImageIcon("Text2Speech.jpg");
		frame.setIconImage(programIcon.getImage());
		frame.setResizable(false);
		lblNewLabel = new JLabel("Author\r\n");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		lblTitle = new JLabel("Title");
		lblTitle.setBackground(Color.DARK_GRAY);
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		
		textField = new JTextField();
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		frame.setVisible(true);
		
		JButton continueButton = new JButton("Continue");
		continueButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String author=textField.getText();
				String title=textField_1.getText();
				factor.setNewDocAuthor(author);
				factor.setNewDocTitle(title);
				createDocumentButton(title,author);
				frame.dispose();
			}
			
		});
		
		
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(187)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblTitle, GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
								.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE))
							.addGap(86))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(105)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE)
								.addComponent(textField, GroupLayout.DEFAULT_SIZE, 255, Short.MAX_VALUE))))
					.addGap(115))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(184)
					.addComponent(continueButton, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(196, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(31)
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField, GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
					.addGap(45)
					.addComponent(lblTitle, GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
					.addGap(19)
					.addComponent(continueButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addContainerGap())
		);
		frame.getContentPane().setLayout(groupLayout);
	}
	


	
	
	public void createDocumentButton(String title, String author) {
		JFrame messageFrame = new JFrame("Create Document");  
	    JButton createButton = new JButton("Create");  
	    messageFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    messageFrame.setBounds(100, 100, 500, 300);
	    createButton.setBounds(200,200,100,25);
	    ImageIcon programIcon = new ImageIcon("Text2Speech.jpg");
		messageFrame.setIconImage(programIcon.getImage());
		createButton.setHorizontalAlignment(SwingConstants.CENTER);
		JLabel lbl1 = new JLabel("You are about to create a new Document file:");
		lbl1.setBackground(Color.DARK_GRAY);
		lbl1.setBounds(130,20,600,100);
		JLabel lbl2 = new JLabel("Author: "+author);
		lbl2.setBackground(Color.DARK_GRAY);
		lbl2.setBounds(130,55,600,100);
		JLabel lbl3 = new JLabel("Title: "+title);
		lbl3.setBackground(Color.DARK_GRAY);
		lbl3.setBounds(130,90,600,100);
		JLabel lbl4 = new JLabel("WARNING: Everything in Text Area will be lost!");
		lbl4.setBackground(Color.DARK_GRAY);
		lbl4.setBounds(130,120,600,100);
		lbl4.setForeground(Color.RED);
	    messageFrame.add(createButton); 
	    messageFrame.add(lbl1);
	    messageFrame.add(lbl2);
	    messageFrame.add(lbl3);
	    messageFrame.add(lbl4);
	    messageFrame.setResizable(false);
	    messageFrame.setLayout(null);  
	    messageFrame.setVisible(true);
	    factor.setNewDocFrame(messageFrame);
	    createButton.addActionListener(factor.createCommand("New Document"));
	    
	}
}

