package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import commands.CommandsFactory;

public class FileMenuView {
	
	private JMenu FileMenu;
	private CommandsFactory factor;
	
	public FileMenuView(JMenu FileMenu,CommandsFactory factor) {
		this.FileMenu = FileMenu;
		this.factor = factor;
		init();
	}
	
	public void init() {
		JMenuItem NewWindowItem = new JMenuItem("New Window");
		NewWindowItem.addActionListener(factor.createCommand("New Window"));
		KeyStroke keyStrokeNewWindow = KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.SHIFT_DOWN_MASK+KeyEvent.CTRL_DOWN_MASK);
		NewWindowItem.setAccelerator(keyStrokeNewWindow);
		FileMenu.add(NewWindowItem);
		
		JMenuItem NewItem = new JMenuItem("New Document");
		KeyStroke keyStrokeNewDocument = KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.CTRL_DOWN_MASK);
		NewItem.setAccelerator(keyStrokeNewDocument);
		NewDocumentView newDocumentView = new NewDocumentView(factor);
		NewItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				newDocumentView.initialize();
			}
			
		});
		FileMenu.add(NewItem);
		
		JMenuItem OpenItem = new JMenuItem("Open File");
		OpenItem.addActionListener(factor.createCommand("Open"));
		KeyStroke keyStrokeToOpen = KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_DOWN_MASK);
		OpenItem.setAccelerator(keyStrokeToOpen);
		FileMenu.add(OpenItem);
		
		JMenuItem SaveAsItem = new JMenuItem("Save As");
		SaveAsItem.addActionListener(factor.createCommand("Save As"));
		KeyStroke keyStrokeToSave = KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.CTRL_DOWN_MASK);
		SaveAsItem.setAccelerator(keyStrokeToSave);
		FileMenu.add(SaveAsItem);
		
		JMenuItem EditDocumentItem = new JMenuItem("Edit Document");
		EditDocumentItem.addActionListener(factor.createCommand("Edit Document"));
		KeyStroke keyStrokeEditDocument = KeyStroke.getKeyStroke(KeyEvent.VK_E, KeyEvent.CTRL_DOWN_MASK);
		EditDocumentItem.setAccelerator(keyStrokeEditDocument);
		FileMenu.add(EditDocumentItem);
		
		JMenuItem PrintItem = new JMenuItem("Print");
		PrintItem.addActionListener(factor.createCommand("Print Document"));
		KeyStroke keyStrokeToPrint = KeyStroke.getKeyStroke(KeyEvent.VK_P, KeyEvent.CTRL_DOWN_MASK);
		PrintItem.setAccelerator(keyStrokeToPrint);
		FileMenu.add(PrintItem);
		
		JMenuItem ExitItem = new JMenuItem("Exit");
		ExitItem.addActionListener(factor.createCommand("Exit"));
		KeyStroke keyStrokeToExit = KeyStroke.getKeyStroke(KeyEvent.VK_F4, KeyEvent.ALT_DOWN_MASK);
		ExitItem.setAccelerator(keyStrokeToExit);
		FileMenu.add(ExitItem);
	}
}