package text2speechapis;



public class FakeTextToSpeechAPI implements TextToSpeechAPI {
	
	
	
	private String text;
	private int rate;
	private int pitch;
	private int volume;
	
	
	
	public FakeTextToSpeechAPI() {
		
	}

	@Override
	public void play(String text) {
		this.text = text;

	}

	@Override
	public void setVolume(int i) {
		volume = i;

	}

	@Override
	public void setPitch(int i) {
		pitch = i;

	}

	@Override
	public void setRate(int i) {
		rate = i;

	}
	public String getText() {
		return text;
	}
	public int getRate() {
		return rate;

	}
	public int getPitch() {
		return pitch;

	}
	public int getVolume() {
		return volume;

	}

}
