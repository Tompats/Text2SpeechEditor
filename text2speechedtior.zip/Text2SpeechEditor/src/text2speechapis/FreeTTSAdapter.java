package text2speechapis;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class FreeTTSAdapter implements TextToSpeechAPI {

	
	private VoiceManager voiceManager;
	private Voice voice;
	
	
	
	public FreeTTSAdapter() {
		System.setProperty("freetts.voices","com.sun.speech.freetts.en.us" + ".cmu_us_kal.KevinVoiceDirectory");
		voiceManager= VoiceManager.getInstance();
		voice = voiceManager.getVoice("kevin16");
	}
	
	
	@Override
	public void play(String text) {
		voice.allocate();
		voice.speak(text);
	}

	@Override
	public void setVolume(int i) {
		double volume = (double)i / 10;
		voice.setVolume((float)volume);

	}

	@Override
	public void setPitch(int i) {
		voice.setPitch((float)i);

	}

	@Override
	public void setRate(int i) {
		voice.setRate((float)i);

	}

}
