package text2speechapis;



public class TextToSpeechAPIFactory{
	private TextToSpeechAPI ttsAPI;
	

	public TextToSpeechAPIFactory() {
		
	}
	
	public TextToSpeechAPI createTTSAPI(String type) {
		if(type.equals("Real")) {
			ttsAPI = new FreeTTSAdapter();
			return ttsAPI;
		}
		else if(type.equals("Fake")) {
			ttsAPI = new FakeTextToSpeechAPI();
			return ttsAPI;
		}
		return null;
	}
}
