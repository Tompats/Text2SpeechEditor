package tests;

import static org.junit.Assert.assertTrue;

import java.io.File;

import java.util.Scanner;

import javax.swing.JTextArea;

import org.junit.jupiter.api.Test;

import commands.OpenDocument;
import commands.ReplayManager;
import view.Text2SpeechEditorView;

class OpenDocumentTest {
	
	
	@Test
	void test() throws Exception {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		JTextArea textarea = new JTextArea();
		ReplayManager replayManager = new ReplayManager(null);
		OpenDocument tester = new OpenDocument(textarea,mainTester.getCurrentDocument(),replayManager);
		tester.actionPerformed(null);
		File file = tester.getFile();
		Scanner input = new Scanner(file);
		StringBuilder sb = new StringBuilder();
		while(input.hasNext()) {
			String[] wordsArray = input.nextLine().split(" ");
			for(int i=0;i<wordsArray.length;i++) {
				if(!wordsArray[i].isEmpty()) {
					if(i==wordsArray.length-1) {
						sb.append(wordsArray[i]);
					}
					else {
						sb.append(wordsArray[i] + " ");
					}
				}
			}
			sb.append("\n");
		}
		input.close();
		System.out.println(mainTester.getCurrentDocument().arrayToText());
		System.out.println(sb.toString());
		assertTrue("Contents of file",mainTester.getCurrentDocument().arrayToText().equals(sb.toString()));
	}

}
