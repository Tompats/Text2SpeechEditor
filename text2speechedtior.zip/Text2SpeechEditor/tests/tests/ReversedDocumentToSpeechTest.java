package tests;

import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import commands.ReplayManager;
import commands.ReversedDocumentToSpeech;
import model.Line;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.Text2SpeechEditorView;

class ReversedDocumentToSpeechTest {

	@Test
	void test() {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		ReplayManager replayManager = new ReplayManager(null);
		TextToSpeechAPIFactory fact = new TextToSpeechAPIFactory();
		Line line = new Line();
		String words[] = new String[3];
		words[0] = "Test";
		words[1] = "Reverse";
		words[2] = "Speech";
		line.setWords(words);
		ArrayList<Line> testArray = new ArrayList<Line>();
		testArray.add(line);
		mainTester.getCurrentDocument().setLines(testArray);
		mainTester.getCurrentDocument().setFakeSpeechAPI(fact);
		ReversedDocumentToSpeech reversedDocToSpeech = new ReversedDocumentToSpeech(mainTester.getCurrentDocument(),replayManager);
		reversedDocToSpeech.actionPerformed(null);
		FakeTextToSpeechAPI faker = (FakeTextToSpeechAPI) mainTester.getCurrentDocument().getLines().get(0).getManager();
		assertTrue("Document to reversed speech",mainTester.getCurrentDocument().getLines().get(0).toReverseString().equals(faker.getText()));
	}

}
