package tests;

import static org.junit.Assert.assertTrue;

import javax.swing.JTextArea;

import org.junit.jupiter.api.Test;

import commands.EditDocument;
import view.Text2SpeechEditorView;

class EditDocumentTest {

	@Test
	void test() {
		JTextArea testArea = new JTextArea();
		testArea.setText("Test Text");
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		assertTrue("Document's Array Is Empty",mainTester.getCurrentDocument().getLines().isEmpty());
		EditDocument test = new EditDocument(testArea,mainTester.getCurrentDocument());
		test.actionPerformed(null);
		assertTrue("Document's Contents",mainTester.getCurrentDocument().getLines().get(0).toString().equals(testArea.getText()));
	}

}
