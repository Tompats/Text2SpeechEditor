package tests;



import static org.junit.Assert.assertFalse;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import commands.ReplayManager;
import commands.TuneEncoding;
import encodingstrategies.AtBashEncoding;
import encodingstrategies.Rot13Encoding;
import model.Line;
import view.Text2SpeechEditorView;

class TuneEncodingTest {

	@Test
	void test() {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		Line line = new Line();
		String words[] = new String[1];
		words[0] = "Test";
		line.setWords(words);
		ArrayList<Line> testArray = new ArrayList<Line>();
		testArray.add(line);
		mainTester.getCurrentDocument().setLines(testArray);
		ReplayManager replayer = new ReplayManager(mainTester.getCurrentDocument());
		TuneEncoding tuner = new TuneEncoding(mainTester.getCurrentDocument(),"Rot-13",replayer);
		tuner.actionPerformed(null);
		Rot13Encoding rott = (Rot13Encoding) mainTester.getCurrentDocument().getEncodingStrategy();
		rott.encode("Test");
		assertFalse("Tune Encoding",mainTester.getCurrentDocument().getLines().get(0).toString().equals(rott.getText()));
		tuner = new TuneEncoding(mainTester.getCurrentDocument(),"AtBash",replayer);
		tuner.actionPerformed(null);
		AtBashEncoding atB = (AtBashEncoding) mainTester.getCurrentDocument().getEncodingStrategy();
		atB.encode("Test");
		assertFalse("Tune Encoding",mainTester.getCurrentDocument().getLines().get(0).toString().equals(atB.getText()));
	}

}
