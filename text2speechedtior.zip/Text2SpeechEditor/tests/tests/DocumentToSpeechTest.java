package tests;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import commands.DocumentToSpeech;
import commands.ReplayManager;
import model.Line;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.Text2SpeechEditorView;

class DocumentToSpeechTest {

	@Test
	void test() {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		ReplayManager replayManager = new ReplayManager(null);
		TextToSpeechAPIFactory fact = new TextToSpeechAPIFactory();
		Line line = new Line();
		String words[] = new String[9];
		words[0] = "Test";
		words[1] = "Speech";
		words[2] = "Document";
		words[3] = "Time";
		words[4] = "Of";
		words[5] = "Execution";
		words[6] = "Test";
		words[7] = "Speech";
		words[8] = "Document";
		line.setWords(words);
		ArrayList<Line> testArray = new ArrayList<Line>();
		testArray.add(line);
		mainTester.getCurrentDocument().setLines(testArray);
		mainTester.getCurrentDocument().setFakeSpeechAPI(fact);
		int x = 0;
		long avg = 0;
		DocumentToSpeech docToSpeech = null;
		while(x <= 10) {
			long startTime = System.nanoTime();
			docToSpeech = new DocumentToSpeech(mainTester.getCurrentDocument(),replayManager);
			long stopTime = System.nanoTime();
			long elapsedTime = stopTime-startTime;
			//System.out.println(elapsedTime);
			avg += elapsedTime;
			x++;
		}
		System.out.println("Average time of transforming: "+ avg +" nanoseconds");
		docToSpeech.actionPerformed(null);
		FakeTextToSpeechAPI faker = (FakeTextToSpeechAPI) mainTester.getCurrentDocument().getLines().get(0).getManager();
		assertTrue("Document to speech",mainTester.getCurrentDocument().getLines().get(0).toString().equals(faker.getText()));
	}

}
