package tests;




import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import org.junit.jupiter.api.Test;
import commands.NewDocument;
import commands.ReplayManager;
import model.Line;
import view.Text2SpeechEditorView;



class NewDocumentTest {

	@Test
	void test() {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		JFrame messageFrame = new JFrame();
		JTextArea textarea = new JTextArea();
		ReplayManager replayManager = new ReplayManager(null);
		Line line = new Line();
		String words[] = new String[1];
		words[0] = "Test";
		line.setWords(words);
		ArrayList<Line> testArray = new ArrayList<Line>();
		testArray.add(line);
		mainTester.getCurrentDocument().setLines(testArray);
		assertFalse("Document's Array Is Empty Before Command",mainTester.getCurrentDocument().getLines().isEmpty());
		NewDocument tester = new NewDocument(mainTester.getCurrentDocument(), "Test Title", "Test Author", messageFrame, textarea, replayManager);
		tester.actionPerformed(null);
		assertTrue("Document's Array Is Empty",mainTester.getCurrentDocument().getLines().isEmpty());
		assertTrue("Document's Title",mainTester.getCurrentDocument().getTitle().equals("Test Title"));
		assertTrue("Document's Author",mainTester.getCurrentDocument().getAuthor().equals("Test Author"));
		assertNotNull("Document's Date",mainTester.getCurrentDocument().getDateCreated());
	}

}
