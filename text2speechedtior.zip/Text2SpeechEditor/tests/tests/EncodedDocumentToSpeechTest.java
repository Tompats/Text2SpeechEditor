package tests;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import commands.EncodedDocumentToSpeech;
import commands.ReplayManager;
import encodingstrategies.FakeEncoding;
import model.Line;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.Text2SpeechEditorView;

class EncodedDocumentToSpeechTest {

	@Test
	void test() {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		ReplayManager replayManager = new ReplayManager(null);
		TextToSpeechAPIFactory fact = new TextToSpeechAPIFactory();
		Line line = new Line();
		String words[] = new String[3];
		words[0] = "Test";
		words[1] = "Speech";
		words[2] = "Encoded";
		line.setWords(words);
		ArrayList<Line> testArray = new ArrayList<Line>();
		testArray.add(line);
		mainTester.getCurrentDocument().setLines(testArray);
		mainTester.getCurrentDocument().setFakeSpeechAPI(fact);
		FakeEncoding fakeEncoding = new FakeEncoding();
		mainTester.getCurrentDocument().tuneEncodingStrategy(fakeEncoding);
		EncodedDocumentToSpeech docToSpeech = new EncodedDocumentToSpeech(mainTester.getCurrentDocument(),replayManager);
		docToSpeech.actionPerformed(null);
		FakeTextToSpeechAPI faker = (FakeTextToSpeechAPI) mainTester.getCurrentDocument().getLines().get(0).getManager();
		System.out.println(faker.getText());
		assertTrue("Document to encoded speech",mainTester.getCurrentDocument().getLines().get(0).toString().equals(faker.getText()));
	}

}
