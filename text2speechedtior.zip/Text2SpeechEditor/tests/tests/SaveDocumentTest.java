package tests;


import static org.junit.Assert.assertTrue;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JTextArea;

import org.junit.jupiter.api.Test;

import commands.ReplayManager;
import commands.SaveDocument;
import model.Line;
import view.Text2SpeechEditorView;

class SaveDocumentTest {
	private StringBuilder sb;
	private File file;

	@Test
	void test() throws FileNotFoundException {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		JTextArea textarea = new JTextArea();
		ReplayManager replayManager = new ReplayManager(null);
		Line line = new Line();
		String words[] = new String[3];
		words[0] = "Test";
		words[1] = "Save";
		words[2] = "Document";
		line.setWords(words);
		ArrayList<Line> testArray = new ArrayList<Line>();
		testArray.add(line);
		testArray.add(line);
		mainTester.getCurrentDocument().setLines(testArray);
		System.out.print(mainTester.getCurrentDocument().arrayToText());
		SaveDocument tester = new SaveDocument(textarea, mainTester.getCurrentDocument(), replayManager);
		tester.actionPerformed(null);
		file = tester.getFile();
		Scanner input = new Scanner(file);
		sb = new StringBuilder();
		while(input.hasNext()) {
			sb.append(input.nextLine()+"\n");
		}
		input.close();
		System.out.println(sb.toString());
		//System.out.print(mainTester.getCurrentDocument().arrayToText());
		assertTrue("Contents of file",mainTester.getCurrentDocument().arrayToText().equals(sb.toString()));
	}

}
