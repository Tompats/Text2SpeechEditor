package tests;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import commands.TuneAudio;
import text2speechapis.FakeTextToSpeechAPI;
import text2speechapis.TextToSpeechAPIFactory;
import view.Text2SpeechEditorView;

class TuneAudioTest {

	@Test
	void test() {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		TextToSpeechAPIFactory fact = new TextToSpeechAPIFactory();
		mainTester.getCurrentDocument().setFakeSpeechAPI(fact);
		int pitchNumber = 200;
		TuneAudio tuner = new TuneAudio(mainTester.getCurrentDocument(),"Pitch",pitchNumber);
		tuner.actionPerformed(null);
		FakeTextToSpeechAPI faker = (FakeTextToSpeechAPI) mainTester.getCurrentDocument().getManager();
		System.out.println(faker.getPitch());
		assertTrue("Pitch",faker.getPitch()==pitchNumber);
		int rateNumber = 78;
		tuner = new TuneAudio(mainTester.getCurrentDocument(),"Rate",rateNumber);
		tuner.actionPerformed(null);
		System.out.println(faker.getRate());
		assertTrue("Pitch",faker.getRate()==rateNumber);
		int volumeNumber = 5;
		tuner = new TuneAudio(mainTester.getCurrentDocument(),"Volume",volumeNumber);
		tuner.actionPerformed(null);
		System.out.println(faker.getVolume());
		assertTrue("Pitch",faker.getVolume()==volumeNumber);
	}

}
