package tests;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import org.junit.jupiter.api.Test;
import commands.NewDocument;
import commands.ReplayCommand;
import commands.ReplayManager;
import view.Text2SpeechEditorView;

class ReplayCommandTest {

	@Test
	void test() {
		Text2SpeechEditorView mainTester = new Text2SpeechEditorView();
		ReplayManager replayManager = new ReplayManager(mainTester.getCurrentDocument());
		JFrame messageFrame = new JFrame();
		JTextArea textarea = new JTextArea();
		NewDocument tester = new NewDocument(mainTester.getCurrentDocument(), "Test Title", "Test Author", messageFrame, textarea, replayManager);
		tester.actionPerformed(null);
		assertFalse("Commands array ",replayManager.getArray().isEmpty());
		assertTrue(replayManager.getArray().get(0).getClass() == NewDocument.class);
		ReplayCommand rep = new ReplayCommand(replayManager);
		rep.actionPerformed(null);
		
	}

}
